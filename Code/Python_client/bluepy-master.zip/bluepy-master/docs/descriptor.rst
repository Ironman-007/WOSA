.. _descriptor:

The ``Descriptor`` class
========================

The Descriptor class is a placeholder. ``bluepy`` does not currently support any useful operations with descriptors.
